//
//  ViewController.swift
//  TestBinet
//
//  Created by Денис Глущенко on 23/1/2567 BE.
//

import UIKit
import SDWebImage

class MainViewController: UIViewController {
    var presenter: MainViewPresenterProtocol!
    var collectionView: UICollectionView!
    var layout: UICollectionViewFlowLayout!
    var backBarButton = UIButton()
    var searchBarButton = UIButton()
    
    var searchBar = UISearchBar()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
       
        view.backgroundColor = Color.navigationBackground
        setupCollectionView()
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.reloadData()
        searchBar.delegate = self
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        view.addSubview(navigationController!.navigationBar)
        setupNavigationBar()
    }
    
    func setupNavigationBar() {
        
        navigationItem.leftBarButtonItem = setupBarButtonItem(button: backBarButton, name: "vector")
        navigationItem.rightBarButtonItem = setupBarButtonItem(button: searchBarButton, name: "search")
        searchBarButton.addTarget(self, action: #selector(searchTapped), for: .touchUpInside)
        
        self.navigationController?.navigationBar.standardAppearance.backgroundColor = Color.navigationBackground
        self.navigationController?.navigationBar.standardAppearance.titleTextAttributes = [NSAttributedString.Key.font: Font.SFProDisplay(with: "Semibold", type: 17),NSAttributedString.Key.foregroundColor: UIColor.white]
        
        title = "Препараты"
    }
    
    func setupBarButtonItem(button: UIButton, name: String ) -> UIBarButtonItem {
        button.setImage(UIImage(named: name), for: .normal)
        button.frame = CGRect.init(x: 0, y: 0, width: 24, height: 24)
                let barButtonItem = UIBarButtonItem.init(customView: button)
        return barButtonItem
        
    }
    
    @objc func searchTapped() {
        navigationItem.titleView = searchBar
        searchBar.showsCancelButton = true
        searchBar.tintColor = UIColor.white
//        navigationItem.rightBarButtonItem = nil
        searchBar.becomeFirstResponder()

    }
    

    func setupCollectionView() {
        layout = setupFlowLayout()
        collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        
        view.addSubview(collectionView)
        collectionView.backgroundColor =  .background
        
        collectionView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate( [
            collectionView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 0),
            collectionView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            collectionView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 0),
            collectionView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: 0)
        ])
        collectionView.register(MainViewCell.self, forCellWithReuseIdentifier: "MainViewCell")
    }
    
    func setupFlowLayout() -> UICollectionViewFlowLayout {
        let layout = UICollectionViewFlowLayout()
        layout.itemSize = .init(width: 164, height: 296)
        layout.minimumLineSpacing =  16
        layout.sectionInset = .init(top: 16, left: 16, bottom: 16, right: 16)
        return layout
    }

}

extension MainViewController: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        presenter.drugs?.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "MainViewCell", for: indexPath) as? MainViewCell else {
            return UICollectionViewCell()
        }
        let drugs = presenter.drugs!
        let url = (drugs[indexPath.row].image)!
        let urlString = "http://shans.d2.i-partner.ru" + url
        guard let url = URL(string: urlString) else { return cell}
        cell.characterImage.sd_setImage(with: url)
        cell.nameLabel.text = drugs[indexPath.row].name?.uppercased()
        cell.descriptionLabel.text = drugs[indexPath.row].description
        cell.activityIndicator.isHidden = true
        return cell
    }
}

extension MainViewController:  UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let drug = presenter.drugs?[indexPath.row]
        presenter.tapOnTheDrug(drug: drug)
    }
}

extension MainViewController : UISearchBarDelegate {
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        presenter.getDrugs()
        collectionView.reloadData()
//        navigationItem.rightBarButtonItem = setupBarButtonItem(button: searchBarButton, name: "search")
        navigationItem.titleView = nil
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
                presenter.search(search: searchText)
                collectionView.reloadData()
    }
    
}


extension MainViewController: MainViewProtocol {
    
    func success() {
        print("Success")
        collectionView.reloadData()
        
    }
    func failure(error: Error) {
        print(error.localizedDescription)
    }
}




