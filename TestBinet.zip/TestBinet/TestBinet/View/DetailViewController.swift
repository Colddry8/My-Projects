//
//  DetailViewController.swift
//  TestBinet
//
//  Created by Денис Глущенко on 23/1/2567 BE.
//

import Foundation
import UIKit
import SDWebImage

class DetailViewController: UIViewController {
   
    var presenter: DetailViewPresenterProtocol!
    var drugView = UIView()
    var drugImage = UIImageView()
    var circleButton = UIButton()
    var starButton = UIButton()
    var nameLabel = UILabel()
    var descriptionLabel = UILabel()
    var whereToBuyButton = UIButton()
    
    var backBarButton = UIButton()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .navigationBackground
        setupDrugView()
        setupImage()
        setImageButtonsConstraint()
        setupLabelsConstraints()
        setupWhereToBuyButton()
        presenter.setDrug()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        view.addSubview(navigationController!.navigationBar)
        navigationItem.leftBarButtonItem = setupBarButtonItem(button: backBarButton, name: "vector")
    }
    
    func setupDrugView() {
        view.addSubview(drugView)
        drugView.backgroundColor = .white
        drugView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            drugView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 0),
            drugView.trailingAnchor.constraint(equalTo: view.trailingAnchor,constant: 0),
            drugView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 0),
            drugView.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: 0)
        ])
    }
    
    
    func setupBarButtonItem(button: UIButton, name: String ) -> UIBarButtonItem {
        button.setImage(UIImage(named: name), for: .normal)
        button.frame = CGRect.init(x: 0, y: 0, width: 24, height: 24)
                let barButtonItem = UIBarButtonItem.init(customView: button)
        button.addTarget(self, action: #selector(backTapped), for: .touchUpInside)
        return barButtonItem
    }
    
    @objc func backTapped() {
        presenter.tap()
    }
    
    
    func setupImage() {
        drugView.addSubview(drugImage)
        
        drugImage.translatesAutoresizingMaskIntoConstraints = false
        drugImage.contentMode = .scaleAspectFit
        

        NSLayoutConstraint.activate([
            drugImage.widthAnchor.constraint(equalToConstant: 343),
            drugImage.heightAnchor.constraint(equalToConstant: 215),
            drugImage.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 14),
            drugImage.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 24)
        ])
    }
    
    func setupImageButtons(button: UIButton, nameImage: String) {
        drugView.addSubview(button)
        button.setImage(UIImage(named: nameImage), for: .normal)
        button.translatesAutoresizingMaskIntoConstraints = false
        
    }
    
    func setImageButtonsConstraint() {
        setupImageButtons(button: circleButton, nameImage: "redButton")
        setupImageButtons(button: starButton, nameImage: "star")
        
        
        NSLayoutConstraint.activate([
            circleButton.widthAnchor.constraint(equalToConstant: 32),
            circleButton.heightAnchor.constraint(equalToConstant: 32),
            circleButton.leadingAnchor.constraint(equalTo: drugImage.leadingAnchor, constant: 16),
            circleButton.trailingAnchor.constraint(equalTo: drugImage.trailingAnchor,constant: -295),
            circleButton.topAnchor.constraint(equalTo: drugImage.topAnchor, constant: 16),
        
            starButton.widthAnchor.constraint(equalToConstant: 32),
            starButton.heightAnchor.constraint(equalToConstant: 32),
            starButton.leadingAnchor.constraint(equalTo: drugImage.leadingAnchor, constant: 295),
            starButton.trailingAnchor.constraint(equalTo: drugImage.trailingAnchor,constant: -16),
            starButton.topAnchor.constraint(equalTo: drugImage.topAnchor, constant: 16)
        ])
    }
    
    func setLabel(label: UILabel, textColor: UIColor, lineHeight: CGFloat, font: UIFont, kern: CGFloat) {
        drugView.addSubview(label)
        label.translatesAutoresizingMaskIntoConstraints = false

        label.textColor = textColor
        label.numberOfLines = 0
    
        let style = NSMutableParagraphStyle()
        style.minimumLineHeight = lineHeight
        style.lineBreakMode = .byWordWrapping
        
        let attributes = [NSAttributedString.Key.paragraphStyle : style,
                          NSAttributedString.Key.font: font,
                          NSAttributedString.Key.kern: kern
        ] as [NSAttributedString.Key : Any]
        
        label.attributedText = NSAttributedString(string: "Наименование", attributes: attributes as [NSAttributedString.Key : Any])
    }
    
    
    
    func setupLabelsConstraints() {
        setLabel(label: nameLabel, textColor: .nameLabel, lineHeight: 28, font: Font.SFProDisplay(with: "Semibold", type: 20), kern: 0.2)
        setLabel(label: descriptionLabel, textColor: .descriptionLabel, lineHeight: 22, font: Font.SFProDisplay(with: "Medium", type: 15), kern: 0.1)
        
        NSLayoutConstraint.activate([
            nameLabel.topAnchor.constraint(equalTo: drugImage.bottomAnchor, constant: 16),
            nameLabel.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 14),
            nameLabel.widthAnchor.constraint(equalToConstant: 328),
            
            descriptionLabel.topAnchor.constraint(equalTo: nameLabel.bottomAnchor, constant: 8),
            descriptionLabel.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 14),
            descriptionLabel.widthAnchor.constraint(equalToConstant: 328),
        ])
    }
    
    func setupWhereToBuyButton() {
        drugView.addSubview(whereToBuyButton)
        whereToBuyButton.translatesAutoresizingMaskIntoConstraints = false
        whereToBuyButton.layer.masksToBounds = true
        whereToBuyButton.layer.cornerRadius = 8
        whereToBuyButton.layer.borderWidth = 1
        whereToBuyButton.layer.borderColor = UIColor.borderGrey.cgColor
        whereToBuyButton.backgroundColor = .background
        
        let locationImage = UIImageView(frame: CGRect(x: 122.5, y: 8, width: 20, height: 20))
        locationImage.image = UIImage(named: "location")
        whereToBuyButton.addSubview(locationImage)
        
        let label = UILabel.init(frame: CGRect(x: 146.5, y: 4, width: 74, height: 20))
        label.textColor = .nameLabel
        label.numberOfLines = 1
    
        let style = NSMutableParagraphStyle()
        style.minimumLineHeight = 20
        
        let attributes = [NSAttributedString.Key.paragraphStyle : style,
                          NSAttributedString.Key.font: Font.SFProDisplay(with: "Semibold", type: 12),
                          NSAttributedString.Key.kern: 0.2
        ] as [NSAttributedString.Key : Any]
        
        label.attributedText = NSAttributedString(string: "Где купить".uppercased(), attributes: attributes as [NSAttributedString.Key : Any])
        whereToBuyButton.addSubview(label)
        
        NSLayoutConstraint.activate([
            whereToBuyButton.widthAnchor.constraint(equalToConstant: 343),
            whereToBuyButton.heightAnchor.constraint(equalToConstant: 36),
            whereToBuyButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 14),
            whereToBuyButton.topAnchor.constraint(equalTo: descriptionLabel.bottomAnchor, constant: 16)
        ])
    }
}

extension DetailViewController: DetailViewProtocol {
    func setDrug(drug: Drug?) {
        nameLabel.text = drug?.name
        descriptionLabel.text = drug?.description
        let url = (drug?.image)!
        let urlString = "http://shans.d2.i-partner.ru" + url
        guard let url = URL(string: urlString) else { return }
        drugImage.sd_setImage(with: url)
    }
}
