//
//  MainViewCell.swift
//  TestBinet
//
//  Created by Денис Глущенко on 23/1/2567 BE.
//
import Foundation
import UIKit
class MainViewCell: UICollectionViewCell {
    
    var nameLabel = UILabel()
    var descriptionLabel = UILabel()
    let characterImage = UIImageView()
    var activityIndicator = UIActivityIndicatorView()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setup()
        setupLabelsConstraints()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    
    func setup() {
        contentView.layer.cornerRadius = 8
        contentView.backgroundColor =  .background
        contentView.layer.shadowOffset = CGSizeMake(0, 0)
        contentView.layer.shadowColor = UIColor.shadow.cgColor
        contentView.layer.shadowOpacity = 4
        contentView.layer.shadowRadius = 4
   
        self.contentView.addSubview(characterImage)
        self.contentView.addSubview(activityIndicator)
        activityIndicator.translatesAutoresizingMaskIntoConstraints = false
        activityIndicator.layer.masksToBounds = true
        activityIndicator.startAnimating()
        characterImage.translatesAutoresizingMaskIntoConstraints = false
        characterImage.layer.masksToBounds = true
        characterImage.layer.cornerRadius = 8
        characterImage.contentMode = .scaleAspectFit

        NSLayoutConstraint.activate([
            characterImage.widthAnchor.constraint(equalToConstant: 140),
            characterImage.heightAnchor.constraint(equalToConstant: 82),
            characterImage.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 12),
            characterImage.trailingAnchor.constraint(equalTo: contentView.trailingAnchor,constant: -12),
            characterImage.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 12),
            activityIndicator.centerXAnchor.constraint(equalTo: contentView.centerXAnchor),
            activityIndicator.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 46)
        ])
    }
    
    func setLabel(label: UILabel, textColor: UIColor, numberOfLines: Int, lineHeight: CGFloat, font: UIFont, kern: CGFloat, lineBreakMode: NSLineBreakMode) {
        self.contentView.addSubview(label)
        label.translatesAutoresizingMaskIntoConstraints = false

        label.textColor = textColor
        label.numberOfLines = 7
    
        let style = NSMutableParagraphStyle()
        style.minimumLineHeight = lineHeight
        style.lineBreakMode = lineBreakMode
        
        let attributes = [NSAttributedString.Key.paragraphStyle : style,
                          NSAttributedString.Key.font: font,
                          NSAttributedString.Key.kern: kern
        ] as [NSAttributedString.Key : Any]
        
        label.attributedText = NSAttributedString(string: "Наименование", attributes: attributes as [NSAttributedString.Key : Any])
    }
    
    
    
    func setupLabelsConstraints() {
        setLabel(label: nameLabel, textColor: .nameLabel, numberOfLines: 0, lineHeight: 20, font: Font.SFProDisplay(with: "Semibold", type: 13), kern: 0.2, lineBreakMode: .byWordWrapping)
        setLabel(label: descriptionLabel, textColor: .descriptionLabel, numberOfLines: 7, lineHeight: 17, font: Font.SFProDisplay(with: "Medium", type: 12), kern: 0.1, lineBreakMode: .byTruncatingTail)
        
        NSLayoutConstraint.activate([
            nameLabel.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 106),
            nameLabel.leadingAnchor.constraint(equalTo: contentView.safeAreaLayoutGuide.leadingAnchor, constant: 12),
            nameLabel.trailingAnchor.constraint(equalTo: contentView.safeAreaLayoutGuide.trailingAnchor, constant: -12),
            nameLabel.widthAnchor.constraint(equalToConstant: 140),
            descriptionLabel.topAnchor.constraint(equalTo: nameLabel.bottomAnchor, constant: 6),
            descriptionLabel.leadingAnchor.constraint(equalTo: contentView.safeAreaLayoutGuide.leadingAnchor, constant: 12),
            descriptionLabel.trailingAnchor.constraint(equalTo: contentView.safeAreaLayoutGuide.trailingAnchor, constant: -16),
            descriptionLabel.widthAnchor.constraint(equalToConstant: 136),
        ])
    }
}
