//
//  Drug.swift
//  TestBinet
//
//  Created by Денис Глущенко on 23/1/2567 BE.
//

import Foundation

struct Drug: Codable {
    var id: Int?
    var image: String?
    var categories: categories?
    var name: String?
    var description: String?
    var documentation: String?
    var fields: [fields]?
}

struct categories: Codable {
    var id: Int
    var icon: String
    var image: String
    var name: String
}

struct fields: Codable {
    var typesId: Int?
    var type: String?
    var name: String?
    var value: String?
    var image: String?
    var flags: flags?
    var show: Int?
    var group: Int?
    enum CodingKeys: String, CodingKey {
        case typesId = "types_id"
    }
}

struct flags: Codable {
    var html: Int?
    var noValue: Int?
    var noName: Int?
    var noImage: Int?
    var noWrap: Int?
    var noWrapName: Int?
    var system: Int
    
    enum CodingKeys: String, CodingKey
    {
        case html
        case noValue = "no_value"
        case noName = "no_name"
        case noImage = "no_image"
        case noWrap = "no_wrap"
        case noWrapName = "no_wrap_name"
        case system
    }
}
