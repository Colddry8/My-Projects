//
//  ModelBuilder.swift
//  TestBinet
//
//  Created by Денис Глущенко on 23/1/2567 BE.
//

import UIKit

protocol AssemblyBuilderProtocol {
    func createMainViewController(router: RouterProtocol) -> UIViewController
    func createDetailViewController(drug: Drug?, router: RouterProtocol) -> UIViewController
    
}

class AssemblyModelBuilder: AssemblyBuilderProtocol {
    func createMainViewController(router: RouterProtocol) -> UIViewController {
        let view = MainViewController()
        let networkService = DrugsClient()
        let presenter = MainPresenter(view: view, networkService: networkService, router: router)
        view.presenter = presenter
        return view
    }
    
    func createDetailViewController(drug: Drug?, router: RouterProtocol) -> UIViewController {
        let view = DetailViewController()
        let networkService = DrugsClient()
        let presenter = DetailPresenter(view: view, networkService: networkService, router: router, drug: drug)
        view.presenter = presenter
        return view
    }
    
    
}
