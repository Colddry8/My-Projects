//
//  DrugsClient.swift
//  TestBinet
//
//  Created by Денис Глущенко on 23/1/2567 BE.
//
import Foundation

protocol NetworkServiceProtocol {
    func getDrugs(completion: @escaping (Result<[Drug]?, Error>) -> Void)
    func searchDrugs(search: String,completion: @escaping (Result<[Drug]?, Error>) -> Void) 
}

class DrugsClient: NetworkServiceProtocol {
    
    
    
    func getDrugs(completion: @escaping (Result<[Drug]?, Error>) -> Void) {
        let urlString = "http://shans.d2.i-partner.ru/api/ppp/index/"
        guard let url = URL(string: urlString) else { return }
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        
        URLSession.shared.dataTask(with: request) { data, _, error in
            if let error = error {
                completion(.failure(error))
                return
            }
            do {
                let responseObject = try JSONDecoder().decode([Drug].self, from: data!)
                completion(.success(responseObject))
            } catch {
                completion(.failure(error))
            }
        } .resume()
    }
    
    func searchDrugs(search: String,completion: @escaping (Result<[Drug]?, Error>) -> Void) {
        let urlString = "http://shans.d2.i-partner.ru/api/ppp/index/?search=" + search
        guard let url = URL(string: urlString) else { return }
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        
        URLSession.shared.dataTask(with: request) { data, _, error in
            if let error = error {
                completion(.failure(error))
                return
            }
            do {
                let responseObject = try JSONDecoder().decode([Drug].self, from: data!)
                completion(.success(responseObject))
            } catch {
                completion(.failure(error))
            }
        } .resume()
    }
}
