//
//  MainViewPresenter.swift
//  TestBinet
//
//  Created by Денис Глущенко on 23/1/2567 BE.
//

import Foundation

protocol MainViewProtocol: AnyObject {
    func success()
    func failure(error: Error)

}

protocol MainViewPresenterProtocol  : AnyObject {
    init(view: MainViewProtocol, networkService: NetworkServiceProtocol, router: RouterProtocol)
    func getDrugs()
    var drugs: [Drug]? { get set }
    func tapOnTheDrug(drug: Drug?)
    
    var search: String? { get set }
    func search(search: String)
}

class MainPresenter: MainViewPresenterProtocol {
    var search: String?
    
   
    
    
    weak var view: MainViewProtocol?
    var router: RouterProtocol?
    let networkService: NetworkServiceProtocol!
    var drugs: [Drug]?
  
    required init(view: MainViewProtocol, networkService: NetworkServiceProtocol, router: RouterProtocol) {
        self.view = view
        self.networkService = networkService
        self.router = router
        getDrugs()
    }
    
    func tapOnTheDrug(drug: Drug?) {
        router?.showDetail(drug: drug)
    }
    
    
    func getDrugs() {
        networkService.getDrugs { [weak self] result in
            guard let self = self else {return}
            DispatchQueue.main.async {
                switch result {
                case .success(let drugs):
                    self.drugs = drugs
                    self.view?.success()
                case .failure(let error):
                    self.view?.failure(error: error)
                }
            }
        }
    }
    
    func search(search: String) {
        networkService.searchDrugs(search: search) { [weak self] result in
            guard let self = self else {return}
            DispatchQueue.main.async {
                switch result {
                case .success(let drugs):
                    self.drugs = drugs
                    self.view?.success()
                case .failure(let error):
                    self.view?.failure(error: error)
                }
            }
        }
    }
}

