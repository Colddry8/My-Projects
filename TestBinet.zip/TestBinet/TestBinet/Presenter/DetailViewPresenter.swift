//
//  DetailViewPresenter.swift
//  TestBinet
//
//  Created by Денис Глущенко on 27/1/2567 BE.
//

import Foundation

protocol DetailViewProtocol: AnyObject {
    func setDrug(drug: Drug?)
}

protocol DetailViewPresenterProtocol: AnyObject {
    init(view: DetailViewProtocol, networkService: NetworkServiceProtocol, router: RouterProtocol, drug: Drug?)
    func setDrug()
    func tap()
}

class DetailPresenter : DetailViewPresenterProtocol {
    
    weak var view: DetailViewProtocol?
    var router: RouterProtocol?
    let networkService: NetworkServiceProtocol!
    var drug: Drug?
    
    required init(view: DetailViewProtocol, networkService: NetworkServiceProtocol, router: RouterProtocol, drug: Drug?) {
        self.view = view
        self.router = router
        self.networkService = networkService
        self.drug = drug
    }
    
   public func setDrug() {
       self.view?.setDrug(drug: drug)
    }
    
    func tap() {
        router?.popToRoot()
    }
    
    
    
}
