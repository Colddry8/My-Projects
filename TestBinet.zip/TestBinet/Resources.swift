//
//  Resources.swift
//  TestBinet
//
//  Created by Денис Глущенко on 24/1/2567 BE.
//

import Foundation
import UIKit
enum Font {
    static func SFProDisplay(with name: String, type: CGFloat) -> UIFont {
        switch name {
        case "Medium" :
            return UIFont(name: "SF Pro Display Medium", size: type) ?? .systemFont(ofSize: 5)
        case "Regular":
            return UIFont(name: "SF Pro Display Regular", size: type) ?? .systemFont(ofSize: 5)
        case "Semibold":
            return UIFont(name: "SF Pro Display Semibold", size: type) ?? .systemFont(ofSize: 5)
        default:
            return .systemFont(ofSize: 10)
        }
    }
}

enum Color {
    static let navigationBackground = UIColor(named: "navigationBackground")
}
